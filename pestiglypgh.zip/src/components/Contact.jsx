function Contactus() {
    return (
      <div className="">
        <div className="max-w-sm mx-auto p-2 border rounded-lg shadow-lg bg-white mt-20 mb-10">
          <h2 className="text-lg font-bold mb-2">Contact Us</h2>
          <form>
            <div className="mb-2">
              <label className="block text-sm font-medium mb-1">Name</label>
              <input type="text" className="input input-bordered w-full" placeholder="Your Name" required />
            </div>
            
            <div className="mb-2">
              <label className="block text-sm font-medium mb-1">Email</label>
              <input type="email" className="input input-bordered w-full" placeholder="Your Email" required />
            </div>
            
            <div className="mb-2">
              <label className="block text-sm font-medium mb-1">Phone</label>
              <input type="tel" className="input input-bordered w-full" placeholder="Your Phone Number" required />
            </div>
            
            <div className="mb-2">
              <label className="block text-sm font-medium mb-1">Additional Comments</label>
              <textarea className="textarea textarea-bordered w-full" placeholder="Your Comments" rows="2"></textarea>
            </div>
            
            <button type="submit" className="btn bg-green-400 w-full p-1">Submit</button>
          </form>
        </div>
      </div>
    );
  }
  
  export default Contactus;
  